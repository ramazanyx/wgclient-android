//========= Copyright © 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================
#pragma once
#if !defined ( VIEWH )
#define VIEWH 

void V_StartPitchDrift( void );
void V_StopPitchDrift( void );

#endif // !VIEWH